package fr.killeverno.claviermaths;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Tampon LaTeX avec curseur. Le curseur se déplace par "morceaux" (une commande
 * comme \alpha ou \right) compte pour un seul pas), pour ne jamais tomber au milieu
 * d'une commande.
 */
public class Editor {

    private static final Pattern TOKEN = Pattern.compile(
            "\\\\begin\\{[a-z]*\\}"
            + "|\\\\end\\{[a-z]*\\}"
            + "|\\\\(?:left|right)\\\\[A-Za-z]+ ?"     // \left\lfloor
            + "|\\\\(?:left|right)\\\\?[^A-Za-z\\s]"   // \left(  \right\}  \left|
            + "|\\\\math(?:bb|cal)\\{.\\}"             // \mathbb{R}
            + "|\\\\[A-Za-z]+ ?[\\{\\[]?"              // \alpha  \frac{  \sqrt[
            + "|\\\\."                                 // \,  \{  \\
            + "|[\\^_]\\{"                             // ^{  _{
            + "|\\]\\{|\\}\\{"                         // ]{  }{
            + "|[\\s\\S]");

    private final StringBuilder buf = new StringBuilder();
    private int cursor = 0;

    public String text() { return buf.toString(); }
    public int cursor() { return cursor; }
    public String before() { return buf.substring(0, cursor); }
    public String after() { return buf.substring(cursor); }
    public boolean isBlank() { return buf.toString().trim().isEmpty(); }

    public void clear() { buf.setLength(0); cursor = 0; }

    /** Débuts des morceaux, plus la fin du texte. */
    private List<Integer> boundaries() {
        List<Integer> b = new ArrayList<>();
        Matcher m = TOKEN.matcher(buf);
        while (m.find()) b.add(m.start());
        b.add(buf.length());
        return b;
    }

    private String tokenAt(int start) {
        Matcher m = TOKEN.matcher(buf);
        if (m.find(start) && m.start() == start) return m.group();
        return "";
    }

    private void snap() {
        int best = 0;
        for (int p : boundaries()) if (p <= cursor) best = p;
        cursor = best;
    }

    /** Insère un extrait ; '§' indique où placer le curseur. */
    public void insert(String snippet) {
        int marker = snippet.indexOf('§');
        String t = snippet.replace("§", "");
        buf.insert(cursor, t);
        cursor += marker >= 0 ? marker : t.length();
        snap();
    }

    public void left() {
        int prev = 0;
        for (int p : boundaries()) { if (p >= cursor) break; prev = p; }
        cursor = prev;
    }

    public void right() {
        for (int p : boundaries()) if (p > cursor) { cursor = p; return; }
        cursor = buf.length();
    }

    /** Va à la case vide suivante (après un '{' ou un '&'), sinon à la fin. */
    public void jumpNext() {
        for (int p : boundaries()) {
            if (p <= cursor || p == 0) continue;
            char c = buf.charAt(p - 1);
            if (c == '{' || c == '&' || c == '[') { cursor = p; return; }
        }
        cursor = buf.length();
    }

    private static boolean isOpener(String t) {
        if (t.equals("}{") || t.equals("]{")) return false;
        return t.endsWith("{") || t.endsWith("[") || t.startsWith("\\left") || t.startsWith("\\begin");
    }

    private static boolean isContinuation(String t) {
        return t.equals("}{") || t.equals("]{") || t.equals("&") || t.startsWith("\\\\");
    }

    private static boolean isCloser(String t) {
        return t.equals("}") || t.equals("]") || t.startsWith("\\right") || t.startsWith("\\end");
    }

    public void backspace() {
        if (cursor == 0) return;
        List<Integer> b = boundaries();
        int start = 0;
        for (int p : b) { if (p >= cursor) break; start = p; }
        String tok = buf.substring(start, cursor);

        if (isCloser(tok) || isContinuation(tok) && !tok.equals("&") && !tok.startsWith("\\\\")) {
            // on entre dans la structure au lieu de la casser
            cursor = start;
            return;
        }
        if (isOpener(tok)) {
            // supprime la structure entière en gardant son contenu
            List<int[]> remove = new ArrayList<>();
            remove.add(new int[]{start, cursor});
            int depth = 1;
            int i = b.indexOf(cursor);
            for (; i >= 0 && i < b.size() - 1; i++) {
                int s = b.get(i), e = b.get(i + 1);
                String t = buf.substring(s, e);
                if (isOpener(t)) depth++;
                else if (isCloser(t)) {
                    depth--;
                    if (depth == 0) { remove.add(new int[]{s, e}); break; }
                } else if (depth == 1 && (t.equals("}{") || t.equals("]{")
                        || tok.startsWith("\\begin") && (t.equals("&") || t.startsWith("\\\\")))) {
                    remove.add(new int[]{s, e});
                }
            }
            if (depth != 0) { // structure mal formée : on supprime juste le morceau
                buf.delete(start, cursor);
                cursor = start;
                return;
            }
            for (int k = remove.size() - 1; k >= 0; k--) buf.delete(remove.get(k)[0], remove.get(k)[1]);
            cursor = start;
            return;
        }
        buf.delete(start, cursor);
        cursor = start;
    }
}
