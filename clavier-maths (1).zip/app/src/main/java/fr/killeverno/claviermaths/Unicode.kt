package fr.killeverno.claviermaths

/** Conversion approximative LaTeX -> texte Unicode, pour envoyer une formule simple en texte. */
object Unicode {

    private val SYMBOLS = mapOf(
        "alpha" to "α", "beta" to "β", "gamma" to "γ", "delta" to "δ", "epsilon" to "ε", "varepsilon" to "ε",
        "zeta" to "ζ", "eta" to "η", "theta" to "θ", "kappa" to "κ", "lambda" to "λ", "mu" to "μ", "nu" to "ν",
        "xi" to "ξ", "pi" to "π", "rho" to "ρ", "sigma" to "σ", "tau" to "τ", "phi" to "ϕ", "varphi" to "φ",
        "chi" to "χ", "psi" to "ψ", "omega" to "ω", "Gamma" to "Γ", "Delta" to "Δ", "Theta" to "Θ",
        "Lambda" to "Λ", "Sigma" to "Σ", "Omega" to "Ω", "Pi" to "Π", "Phi" to "Φ", "Psi" to "Ψ",
        "int" to "∫", "sum" to "∑", "prod" to "∏", "infty" to "∞", "partial" to "∂", "nabla" to "∇",
        "to" to "→", "mapsto" to "↦", "Rightarrow" to "⇒", "Leftrightarrow" to "⇔", "neg" to "¬",
        "land" to "∧", "lor" to "∨", "forall" to "∀", "exists" to "∃", "in" to "∈", "notin" to "∉",
        "subset" to "⊂", "subseteq" to "⊆", "cup" to "∪", "cap" to "∩", "setminus" to "∖", "emptyset" to "∅",
        "times" to "×", "div" to "÷", "cdot" to "·", "pm" to "±", "neq" to "≠", "leq" to "≤", "geq" to "≥",
        "approx" to "≈", "equiv" to "≡", "circ" to "∘", "mid" to "|", "dots" to "…", "prime" to "′",
        "llbracket" to "⟦", "rrbracket" to "⟧", "lfloor" to "⌊", "rfloor" to "⌋",
        "sin" to "sin", "cos" to "cos", "tan" to "tan", "ln" to "ln", "log" to "log", "exp" to "exp", "lim" to "lim",
        "top" to "ᵀ", "ni" to "∋", "supset" to "⊃", "subsetneq" to "⊊", "leqslant" to "⩽", "geqslant" to "⩾",
        "ll" to "≪", "gg" to "≫", "simeq" to "≃", "sim" to "∼", "iint" to "∬", "iiint" to "∭", "oint" to "∮",
        "longrightarrow" to "⟶", "Longrightarrow" to "⟹", "nearrow" to "↗", "searrow" to "↘", "epsilon" to "ϵ",
        "vartheta" to "ϑ", "varnothing" to "∅", "not" to "¬",
        "%" to "%", "_" to "_", "{" to "{", "}" to "}", "|" to "‖",
    )

    private val BB = mapOf('R' to "ℝ", 'N' to "ℕ", 'Z' to "ℤ", 'Q' to "ℚ", 'C' to "ℂ", 'K' to "𝕂", 'U' to "𝕌")

    private const val SUP_SRC = "0123456789+-=()niktx′"
    private const val SUP_DST = "⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻⁼⁽⁾ⁿⁱᵏᵗˣ′"
    private const val SUB_SRC = "0123456789+-=()aeijknoxmp"
    private const val SUB_DST = "₀₁₂₃₄₅₆₇₈₉₊₋₌₍₎ₐₑᵢⱼₖₙₒₓₘₚ"

    fun convert(tex: String): String {
        var s = tex
        s = s.replace("\\left", "").replace("\\right", "").replace("\\,", " ").replace("\\ ", " ")
            .replace("\\mathrm", "").replace("\\text", "")
        s = s.replace(Regex("\\\\mathbb\\{(\\w)\\}")) { BB[it.groupValues[1][0]] ?: it.groupValues[1] }
        s = s.replace(Regex("\\\\mathbb (\\w)")) { BB[it.groupValues[1][0]] ?: it.groupValues[1] }
        // structures imbriquées : on répète jusqu'à stabilité
        repeat(10) {
            val before = s
            s = s.replace(Regex("\\\\frac\\{([^{}]*)\\}\\{([^{}]*)\\}")) { "${wrap(it.groupValues[1])}/${wrap(it.groupValues[2])}" }
            s = s.replace(Regex("\\\\binom\\{([^{}]*)\\}\\{([^{}]*)\\}")) { "C(${it.groupValues[1]}, ${it.groupValues[2]})" }
            s = s.replace(Regex("\\\\sqrt\\[([^\\]]*)\\]\\{([^{}]*)\\}")) { "${script(it.groupValues[1], true)}√${wrap(it.groupValues[2])}" }
            s = s.replace(Regex("\\\\sqrt\\{([^{}]*)\\}")) { "√${wrap(it.groupValues[1])}" }
            s = s.replace(Regex("\\\\(overline|vec)\\{([^{}]*)\\}")) { it.groupValues[2] + if (it.groupValues[1] == "vec") "⃗" else "̄" }
            s = s.replace(Regex("\\^\\{([^{}]*)\\}")) { script(it.groupValues[1], true) }
            s = s.replace(Regex("_\\{([^{}]*)\\}")) { script(it.groupValues[1], false) }
            if (s == before) return@repeat
        }
        s = s.replace(Regex("\\^(\\\\prime|.)")) { script(if (it.groupValues[1] == "\\prime") "′" else it.groupValues[1], true) }
        s = s.replace(Regex("_(.)")) { script(it.groupValues[1], false) }
        s = s.replace(Regex("\\\\([A-Za-z]+|.)\\s?")) { m ->
            val name = m.groupValues[1]
            val sym = SYMBOLS[name] ?: name
            if (name in listOf("sin", "cos", "tan", "ln", "log", "exp", "lim")) "$sym " else sym
        }
        s = s.replace("{", "").replace("}", "")
        return s.replace(Regex(" {2,}"), " ").trim()
    }

    private fun wrap(x: String): String {
        val t = x.trim()
        return if (t.length <= 1 || t.all { it.isLetterOrDigit() }) t else "($t)"
    }

    private fun script(x: String, sup: Boolean): String {
        val src = if (sup) SUP_SRC else SUB_SRC
        val dst = if (sup) SUP_DST else SUB_DST
        val t = x.replace("\\prime", "′").replace(" ", "")
        return if (t.isNotEmpty() && t.all { src.indexOf(it) >= 0 }) {
            t.map { dst[src.indexOf(it)] }.joinToString("")
        } else {
            (if (sup) "^" else "_") + wrap(x)
        }
    }
}
