package fr.killeverno.claviermaths

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply {
            textSize = 22f
            text = "Clavier Maths"
        })
        root.addView(TextView(this).apply {
            textSize = 15f
            setPadding(0, pad, 0, pad)
            text = "1. Active « Clavier Maths » dans les claviers.\n" +
                "2. Choisis-le comme clavier actif.\n" +
                "3. Teste-le dans le champ ci-dessous, puis dans WhatsApp.\n\n" +
                "• Image ➤ : envoie la formule en image\n" +
                "• Texte ↗ : insère une version texte (x², √, ∫…)\n" +
                "• LaTeX ↗ : insère le code LaTeX\n" +
                "• ⇥ : passe à la case suivante (ex. dénominateur)\n" +
                "• 🌐 : revient à ton clavier normal"
        })
        root.addView(Button(this).apply {
            text = "1. Activer le clavier"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "2. Choisir le clavier"
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })
        root.addView(EditText(this).apply { hint = "Zone de test" })
        setContentView(root)
    }
}
