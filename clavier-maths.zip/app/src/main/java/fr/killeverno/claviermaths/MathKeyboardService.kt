package fr.killeverno.claviermaths

import android.annotation.SuppressLint
import android.content.ClipDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import org.json.JSONObject
import java.io.File

class MathKeyboardService : InputMethodService() {

    private val main = Handler(Looper.getMainLooper())

    private val buffer = StringBuilder()
    private var cursor = 0
    private var pageIndex = 0
    private var shift = false

    private lateinit var webView: WebView
    private lateinit var sourceView: TextView
    private lateinit var keysContainer: LinearLayout
    private lateinit var tabsRow: LinearLayout

    // Couleurs
    private val bg = Color.parseColor("#1E1F24")
    private val keyBg = Color.parseColor("#3A3C44")
    private val keyBgAlt = Color.parseColor("#2C2E35")
    private val accent = Color.parseColor("#4F8CFF")
    private val fg = Color.WHITE

    private fun dp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    // ---------- Vue ----------

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(3f), dp(3f), dp(3f), dp(3f))
        }

        // Aperçu de la formule
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.allowFileAccess = true
            isVerticalScrollBarEnabled = false
            setBackgroundColor(Color.WHITE)
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = WebViewClient()
            loadUrl("file:///android_asset/render.html")
        }
        root.addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(78f)))

        // Code LaTeX avec curseur
        sourceView = TextView(this).apply {
            setTextColor(Color.parseColor("#C9D1D9"))
            typeface = Typeface.MONOSPACE
            textSize = 13f
            isSingleLine = true
            setPadding(dp(8f), dp(4f), dp(8f), dp(4f))
        }
        val sourceScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(sourceView)
        }
        root.addView(sourceScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28f)))

        // Actions
        val actions = row()
        actions.addView(button("✕", keyBgAlt) { clearBuffer() }, lp(0.7f))
        actions.addView(button("LaTeX ↗", keyBgAlt) { commitText(buffer.toString()) }, lp(1.3f))
        actions.addView(button("Texte ↗", keyBgAlt) { commitText(Unicode.convert(buffer.toString())) }, lp(1.3f))
        actions.addView(button("Image ➤", accent) { sendImage() }, lp(1.7f))
        root.addView(actions, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42f)))

        // Onglets
        tabsRow = row()
        root.addView(tabsRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38f)))

        // Touches
        keysContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(keysContainer, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(5 * 46f)))

        // Ligne du bas
        val bottom = row()
        bottom.addView(button("🌐", keyBgAlt) { switchKeyboard() }, lp(1f))
        bottom.addView(button("◀", keyBgAlt) { moveCursor(-1) }, lp(1f))
        bottom.addView(button("▶", keyBgAlt) { moveCursor(1) }, lp(1f))
        bottom.addView(button("⇥", keyBgAlt) { jumpNext() }, lp(1f))
        bottom.addView(button("espace", keyBg) { insert(" ") }, lp(2f))
        bottom.addView(repeatButton("⌫", keyBgAlt) { backspace() }, lp(1.2f))
        root.addView(bottom, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46f)))

        buildTabs()
        buildKeys()
        refresh()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        refresh()
    }

    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

    private fun lp(weight: Float) = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)

    private fun styledKey(label: String, color: Int): TextView = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        setTextColor(fg)
        textSize = if (label.length > 3) 14f else 19f
        background = GradientDrawable().apply { cornerRadius = dp(6f).toFloat(); setColor(color) }
        isClickable = true
    }

    private fun wrapMargin(v: View): View {
        val frame = LinearLayout(this)
        frame.setPadding(dp(2f), dp(2f), dp(2f), dp(2f))
        frame.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        return frame
    }

    private fun button(label: String, color: Int, onClick: () -> Unit): View {
        val v = styledKey(label, color)
        v.setOnClickListener { onClick() }
        return wrapMargin(v)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun repeatButton(label: String, color: Int, action: () -> Unit): View {
        val v = styledKey(label, color)
        val repeater = object : Runnable {
            override fun run() { action(); main.postDelayed(this, 60) }
        }
        v.setOnTouchListener { view, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { view.isPressed = true; action(); main.postDelayed(repeater, 400) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { view.isPressed = false; main.removeCallbacks(repeater) }
            }
            true
        }
        return wrapMargin(v)
    }

    private fun currentPage(): Page {
        val p = Keys.PAGES[pageIndex]
        return if (p === Keys.LETTERS && shift) Keys.LETTERS_UP else p
    }

    private fun buildTabs() {
        tabsRow.removeAllViews()
        Keys.PAGES.forEachIndexed { i, page ->
            val color = if (i == pageIndex) accent else keyBgAlt
            tabsRow.addView(button(page.tab, color) {
                pageIndex = i
                buildTabs(); buildKeys()
            }, lp(1f))
        }
    }

    private fun buildKeys() {
        keysContainer.removeAllViews()
        val page = currentPage()
        val rowCount = page.rows.size
        for (r in page.rows) {
            val line = row()
            for (key in r) {
                line.addView(button(key.label, if (key.insert == Keys.SHIFT && shift) accent else keyBg) { onKey(key) }, lp(key.weight))
            }
            keysContainer.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        // garde une hauteur constante quand une page a moins de lignes
        for (i in rowCount until 5) {
            keysContainer.addView(View(this), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 0f))
        }
    }

    // ---------- Édition du tampon ----------

    private fun onKey(key: Key) {
        if (key.insert == Keys.SHIFT) {
            shift = !shift; buildKeys(); return
        }
        insert(key.insert)
        if (shift && Keys.PAGES[pageIndex] === Keys.LETTERS) { shift = false; buildKeys() }
    }

    private fun insert(snippet: String) {
        val marker = snippet.indexOf('§')
        val text = snippet.replace("§", "")
        buffer.insert(cursor, text)
        cursor += if (marker >= 0) marker else text.length
        refresh()
    }

    private fun backspace() {
        if (cursor == 0) return
        // efface une commande entière (ex. "\alpha ") d'un coup
        val before = buffer.substring(0, cursor)
        val m = Regex("\\\\[A-Za-z]+ ?$").find(before)
        val start = m?.range?.first ?: (cursor - 1)
        buffer.delete(start, cursor)
        cursor = start
        refresh()
    }

    private fun moveCursor(d: Int) {
        cursor = (cursor + d).coerceIn(0, buffer.length)
        refresh()
    }

    /** Saute à l'emplacement vide suivant ({} ou &) ou à la fin. */
    private fun jumpNext() {
        val s = buffer.toString()
        val brace = s.indexOf('{', cursor)
        val amp = s.indexOf('&', cursor)
        val targets = listOfNotNull(
            if (brace >= 0) brace + 1 else null,
            if (amp >= 0) amp + 1 else null
        )
        cursor = targets.minOrNull() ?: s.length
        refresh()
    }

    private fun clearBuffer() {
        buffer.setLength(0); cursor = 0; refresh()
    }

    private fun refresh() {
        if (!::sourceView.isInitialized) return
        val s = buffer.toString()
        sourceView.text = if (s.isEmpty()) "│" else s.substring(0, cursor) + "│" + s.substring(cursor)
        webView.evaluateJavascript("render(${JSONObject.quote(s)})", null)
    }

    // ---------- Envoi ----------

    private fun commitText(text: String) {
        if (text.isBlank()) return
        currentInputConnection?.commitText(text, 1)
        clearBuffer()
    }

    private fun sendImage() {
        if (buffer.isBlank()) return
        webView.evaluateJavascript("exportPng(${JSONObject.quote(buffer.toString())}, 22, 30)", null)
    }

    private fun onPngReady(base64: String) {
        val bytes = Base64.decode(base64, Base64.DEFAULT)
        val dir = File(cacheDir, "images").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val file = File(dir, "formule_${System.currentTimeMillis()}.png")
        file.writeBytes(bytes)
        val uri: Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)

        val info = currentInputEditorInfo
        val ic = currentInputConnection
        val mimes = if (info != null) EditorInfoCompat.getContentMimeTypes(info) else emptyArray()
        val supportsPng = mimes.any { ClipDescription.compareMimeTypes("image/png", it) }

        if (ic != null && info != null && supportsPng) {
            val content = InputContentInfoCompat(uri, ClipDescription("Formule", arrayOf("image/png")), null)
            val ok = InputConnectionCompat.commitContent(
                ic, info, content, InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null
            )
            if (ok) { clearBuffer(); return }
        }
        // Repli : feuille de partage Android
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(send, "Envoyer la formule").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(chooser)
            clearBuffer()
        } catch (e: Exception) {
            Toast.makeText(this, "Impossible de partager : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun switchKeyboard() {
        if (android.os.Build.VERSION.SDK_INT >= 28 && switchToNextInputMethod(false)) return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    inner class Bridge {
        @JavascriptInterface fun onReady() { main.post { refresh() } }
        @JavascriptInterface fun onPng(base64: String) { main.post { onPngReady(base64) } }
        @JavascriptInterface fun onExportError(msg: String) {
            main.post { Toast.makeText(this@MathKeyboardService, "Formule invalide : $msg", Toast.LENGTH_SHORT).show() }
        }
    }
}
