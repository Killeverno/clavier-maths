package fr.killeverno.claviermaths

/**
 * Une touche : [label] est ce qui est affiché, [insert] est le LaTeX inséré.
 * Le caractère '§' dans [insert] indique où placer le curseur après l'insertion.
 */
data class Key(val label: String, val insert: String, val weight: Float = 1f)

data class Page(val tab: String, val rows: List<List<Key>>)

private fun k(label: String, insert: String = label, weight: Float = 1f) = Key(label, insert, weight)

object Keys {

    val BASE = Page(
        "f(x)", listOf(
            listOf(k("x"), k("y"), k("n"), k("k"), k("f"), k("i")),
            listOf(k("xⁿ", "^{§}"), k("xₙ", "_{§}"), k("a⁄b", "\\frac{§}{}"), k("√", "\\sqrt{§}"), k("ⁿ√", "\\sqrt[§]{}"), k("|x|", "\\left|§\\right|")),
            listOf(k("(", "\\left(§\\right)"), k("[ ]", "\\left[§\\right]"), k("{ }", "\\left\\{§\\right\\}"), k("f′", "^{\\prime}"), k("f″", "^{\\prime\\prime}"), k("·", "\\cdot ")),
            listOf(k("="), k("≠", "\\neq "), k("≤", "\\leq "), k("≥", "\\geq "), k("<"), k(">")),
            listOf(k("+"), k("−", "-"), k("×", "\\times "), k("±", "\\pm "), k("∞", "\\infty "), k("≈", "\\approx ")),
        )
    )

    val NUM = Page(
        "123", listOf(
            listOf(k("7"), k("8"), k("9"), k("+"), k("−", "-"), k("("), ),
            listOf(k("4"), k("5"), k("6"), k("×", "\\times "), k("÷", "\\div "), k(")")),
            listOf(k("1"), k("2"), k("3"), k("="), k("%", "\\%"), k("!")),
            listOf(k("0"), k(","), k("."), k("x²", "^{2}"), k("10ⁿ", "10^{§}"), k("…", "\\dots ")),
        )
    )

    val ANALYSE = Page(
        "∫∑", listOf(
            listOf(k("∫", "\\int "), k("∫ₐᵇ", "\\int_{§}^{}"), k("dx", "\\,\\mathrm{d}x"), k("∑", "\\sum_{§}^{}"), k("∏", "\\prod_{§}^{}"), k("lim", "\\lim_{§}")),
            listOf(k("→", "\\to "), k("↦", "\\mapsto "), k("eˣ", "e^{§}"), k("ln", "\\ln "), k("exp", "\\exp "), k("log", "\\log ")),
            listOf(k("sin", "\\sin "), k("cos", "\\cos "), k("tan", "\\tan "), k("∂", "\\partial "), k("d⁄dx", "\\frac{\\mathrm{d}§}{\\mathrm{d}x}"), k("∇", "\\nabla ")),
            listOf(k("(ⁿₖ)", "\\binom{§}{}"), k("‖x‖", "\\left\\|§\\right\\|"), k("⌊x⌋", "\\left\\lfloor §\\right\\rfloor"), k("x̄", "\\overline{§}"), k("u⃗", "\\vec{§}"), k("o()", "o\\left(§\\right)")),
            listOf(k("mat", "\\begin{pmatrix} § & \\\\  & \\end{pmatrix}", 1.5f), k("&", "&"), k("↵", "\\\\ "), k("cas", "\\begin{cases} § & \\\\  & \\end{cases}", 1.5f)),
        )
    )

    val LOGIQUE = Page(
        "∀∈", listOf(
            listOf(k("∀", "\\forall "), k("∃", "\\exists "), k("∈", "\\in "), k("∉", "\\notin "), k("⊂", "\\subset "), k("⊆", "\\subseteq ")),
            listOf(k("ℝ", "\\mathbb{R}"), k("ℕ", "\\mathbb{N}"), k("ℤ", "\\mathbb{Z}"), k("ℚ", "\\mathbb{Q}"), k("ℂ", "\\mathbb{C}"), k("∅", "\\emptyset ")),
            listOf(k("∪", "\\cup "), k("∩", "\\cap "), k("∖", "\\setminus "), k("×", "\\times "), k("∘", "\\circ "), k("𝒫", "\\mathcal{P}\\left(§\\right)")),
            listOf(k("⇒", "\\Rightarrow "), k("⇔", "\\Leftrightarrow "), k("¬", "\\neg "), k("∧", "\\land "), k("∨", "\\lor "), k("≡", "\\equiv ")),
            listOf(k("⟦ ⟧", "\\llbracket §\\rrbracket"), k(";", ";"), k(":", ":"), k("|", "\\mid "), k("txt", "\\text{§}"), k("␣", "\\ ")),
        )
    )

    val GREC = Page(
        "αβ", listOf(
            listOf(k("α", "\\alpha "), k("β", "\\beta "), k("γ", "\\gamma "), k("δ", "\\delta "), k("ε", "\\varepsilon "), k("θ", "\\theta ")),
            listOf(k("λ", "\\lambda "), k("μ", "\\mu "), k("π", "\\pi "), k("ρ", "\\rho "), k("σ", "\\sigma "), k("τ", "\\tau ")),
            listOf(k("φ", "\\varphi "), k("χ", "\\chi "), k("ψ", "\\psi "), k("ω", "\\omega "), k("ν", "\\nu "), k("ξ", "\\xi ")),
            listOf(k("Γ", "\\Gamma "), k("Δ", "\\Delta "), k("Θ", "\\Theta "), k("Λ", "\\Lambda "), k("Σ", "\\Sigma "), k("Ω", "\\Omega ")),
            listOf(k("Π", "\\Pi "), k("Φ", "\\Phi "), k("Ψ", "\\Psi "), k("ζ", "\\zeta "), k("η", "\\eta "), k("κ", "\\kappa ")),
        )
    )

    private fun letters(upper: Boolean): Page {
        fun row(s: String) = s.map { c -> (if (upper) c.uppercaseChar() else c).toString().let { k(it) } }
        return Page(
            "abc", listOf(
                row("azertyuiop"),
                row("qsdfghjklm"),
                row("wxcvbn") + listOf(k("'", "'"), k("_", "\\_"), k("⇧", SHIFT, 1.5f)),
            )
        )
    }

    const val SHIFT = "__SHIFT__"

    val LETTERS = letters(false)
    val LETTERS_UP = letters(true)

    val PAGES = listOf(BASE, ANALYSE, LOGIQUE, GREC, NUM, LETTERS)
}
